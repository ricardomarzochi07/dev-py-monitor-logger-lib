# dev-py-monitor-logger-lib
Library Python - Proceso Trazabilidad Logger Standard
